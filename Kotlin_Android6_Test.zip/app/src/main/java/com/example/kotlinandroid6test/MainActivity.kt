package com.example.kotlinandroid6test

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private var count = 0
    private lateinit var countText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 32)
        window.navigationBarColor = Color.rgb(16, 24, 32)
        buildScreen()
    }

    private fun buildScreen() {
        val background = Color.rgb(13, 18, 26)
        val accent = Color.rgb(0, 188, 212)
        val white = Color.rgb(245, 247, 250)
        val muted = Color.rgb(170, 180, 193)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(background)
        }

        val title = TextView(this).apply {
            text = "Kotlin works!"
            textSize = 30f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "تطبيق أندرويد أصلي • Android 6+"
            textSize = 16f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(28))
        }
        root.addView(subtitle, matchWrap())

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(22), dp(20), dp(22))
            setBackgroundColor(Color.rgb(25, 34, 45))
        }
        root.addView(card, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val label = TextView(this).apply {
            text = "عداد اختبار"
            textSize = 18f
            setTextColor(white)
            gravity = Gravity.CENTER
        }
        card.addView(label, matchWrap())

        countText = TextView(this).apply {
            text = count.toString()
            textSize = 48f
            setTextColor(accent)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(16))
        }
        card.addView(countText, matchWrap())

        val addButton = Button(this).apply {
            text = "اضغط لزيادة العداد"
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(0, 121, 140))
            setOnClickListener {
                count += 1
                countText.text = count.toString()
            }
        }
        card.addView(addButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
        ))

        val resetButton = Button(this).apply {
            text = "إعادة التعيين"
            textSize = 15f
            setOnClickListener {
                count = 0
                countText.text = count.toString()
            }
        }
        val resetParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
        )
        resetParams.topMargin = dp(8)
        card.addView(resetButton, resetParams)

        val footer = TextView(this).apply {
            text = "إذا ظهرت هذه الشاشة، فقد تم تشغيل كود Kotlin بنجاح."
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        root.addView(footer, matchWrap())

        setContentView(root)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
